# info covid

[![Build Status](http://img.shields.io/travis/badges/badgerbadgerbadger.svg?style=flat-square)](https://travis-ci.org/badges/badgerbadgerbadger) [![Coverage Status](http://img.shields.io/coveralls/badges/badgerbadgerbadger.svg?style=flat-square)](https://coveralls.io/r/badges/badgerbadgerbadger)

application to monitor the number of covid sufferers in Indonesia, the application is made using the php language

## Installation

```sh
git clone https://github.com/imsoftware-id/infocovid.git
```
or download 
```sh
 https://github.com/imsoftware-id/infocovid
```

## Usage

running on webserver and php5-php7.*

## Contributing
Contributions are always welcome!

## License
[MIT](https://choosealicense.com/licenses/mit/)